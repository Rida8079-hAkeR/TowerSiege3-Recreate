
### Features of Stage 3:
##### On Space button pressed, player gets a second chance to play
##### Score card is calculated 
##### Blocks vanish on coming in contact with my slingshot





